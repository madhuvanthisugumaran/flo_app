import { useState, useMemo } from "react";
import { Calendar as CalendarIcon, Eye, EyeOff, ChevronLeft, ChevronRight, ArrowLeft, Droplet } from "lucide-react";

const PINK_BG = "#f2d0de";
const PINK_HEADER = "#d987a9";
const PINK_BTN = "#ec9ec2";
const PINK_BTN_DARK = "#e086b3";
const INPUT_BG = "#fdf5f6";
const PURPLE = "#6d3f9e";
const LIGHT_CIRCLE = "#f3bcd3";

function fmtISO(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function addDays(d, n) {
  const r = new Date(d);
  r.setDate(r.getDate() + n);
  return r;
}

function daysBetween(a, b) {
  const ms = new Date(b.getFullYear(), b.getMonth(), b.getDate()) -
    new Date(a.getFullYear(), a.getMonth(), a.getDate());
  return Math.round(ms / 86400000);
}

function monthMatrix(year, month) {
  const first = new Date(year, month, 1);
  const startWeekday = first.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  return cells;
}

function Header({ title }) {
  return (
    <div
      className="mx-auto mb-6 rounded-md px-6 py-4 text-center"
      style={{ background: PINK_HEADER, maxWidth: 260 }}
    >
      <span className="text-white font-bold tracking-wide text-lg">{title}</span>
    </div>
  );
}

function PinkButton({ children, onClick, variant = "solid", full = false, style = {} }) {
  const base =
    "rounded-md px-5 py-2 font-semibold text-sm tracking-wide transition active:scale-95";
  const bg = variant === "solid" ? PINK_BTN : PINK_BTN_DARK;
  return (
    <button
      onClick={onClick}
      className={base + (full ? " w-full" : "")}
      style={{ background: bg, color: "#3a2233", ...style }}
    >
      {children}
    </button>
  );
}

function Field({ label, children }) {
  return (
    <div className="mb-4 text-left">
      <label className="block text-sm font-medium text-[#3a2233] mb-1">{label}</label>
      {children}
    </div>
  );
}

function TextField({ value, onChange, type = "text", placeholder, error }) {
  return (
    <div>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-sm px-3 py-2 text-sm outline-none border border-transparent focus:border-[#d987a9]"
        style={{ background: INPUT_BG }}
      />
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </div>
  );
}

function MiniCalendar({ year, month, setYear, setMonth, selectedDay, onSelectDay, markedDays, today }) {
  const cells = monthMatrix(year, month);
  const monthLabel = new Date(year, month, 1).toLocaleString("default", {
    month: "long",
    year: "numeric",
  });

  const prevMonth = () => {
    if (month === 0) {
      setMonth(11);
      setYear(year - 1);
    } else setMonth(month - 1);
  };
  const nextMonth = () => {
    if (month === 11) {
      setMonth(0);
      setYear(year + 1);
    } else setMonth(month + 1);
  };

  const selectedLabel =
    selectedDay != null
      ? new Date(year, month, selectedDay).toLocaleDateString("en-US", {
          weekday: "short",
          month: "short",
          day: "numeric",
        })
      : "";

  return (
    <div className="rounded-xl p-4" style={{ background: PINK_BG, border: `1px solid ${PINK_HEADER}44` }}>
      <p className="text-xs text-[#6b4a5c] mb-1">Select date</p>
      <div className="flex items-center justify-between mb-3">
        <span className="text-xl font-semibold text-[#3a2233]">{selectedLabel}</span>
        <span className="text-[#6b4a5c]">✎</span>
      </div>
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-[#3a2233]">{monthLabel}</span>
        <div className="flex gap-3">
          <button onClick={prevMonth} aria-label="Previous month">
            <ChevronLeft size={16} className="text-[#6b4a5c]" />
          </button>
          <button onClick={nextMonth} aria-label="Next month">
            <ChevronRight size={16} className="text-[#6b4a5c]" />
          </button>
        </div>
      </div>
      <div className="grid grid-cols-7 text-center text-xs text-[#6b4a5c] mb-1">
        {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => (
          <div key={i}>{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-y-1 text-center text-sm">
        {cells.map((day, i) => {
          if (day == null) return <div key={i} />;
          const iso = fmtISO(new Date(year, month, day));
          const isToday = iso === fmtISO(today);
          const isSelected = day === selectedDay;
          const isMarked = markedDays.has(iso);
          let cls = "mx-auto w-7 h-7 flex items-center justify-center rounded-full cursor-pointer";
          let style = { color: "#3a2233" };
          if (isSelected) {
            style = { background: PURPLE, color: "white" };
          } else if (isToday) {
            style = { border: `1px solid ${PURPLE}`, color: PURPLE };
          } else if (isMarked) {
            style = { background: LIGHT_CIRCLE, color: "#3a2233" };
          }
          return (
            <div key={i} className={cls} style={style} onClick={() => onSelectDay(day)}>
              {day}
            </div>
          );
        })}
      </div>
      <div className="flex justify-between mt-3 text-sm font-medium text-[#5a3d6b]">
        <button onClick={() => onSelectDay(null)}>Clear</button>
      </div>
    </div>
  );
}

export default function FloApp() {
  const today = useMemo(() => new Date(), []);
  const [screen, setScreen] = useState("login");

  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loginError, setLoginError] = useState("");

  const [signupName, setSignupName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupError, setSignupError] = useState("");

  const [lastPeriodStart, setLastPeriodStart] = useState(fmtISO(addDays(today, -9)));
  const [periodLength, setPeriodLength] = useState(5);
  const [cycleLength, setCycleLength] = useState(28);
  const [setupError, setSetupError] = useState("");

  const [calYear, setCalYear] = useState(today.getFullYear());
  const [calMonth, setCalMonth] = useState(today.getMonth());
  const [calSelectedDay, setCalSelectedDay] = useState(today.getDate());

  const [logYear, setLogYear] = useState(today.getFullYear());
  const [logMonth, setLogMonth] = useState(today.getMonth());
  const [logSelectedDay, setLogSelectedDay] = useState(today.getDate());

  const emailValid = (v) => /\S+@\S+\.\S+/.test(v);

  // ---- predicted / logged period days as a set of ISO strings, spanning a wide window ----
  const markedDays = useMemo(() => {
    const set = new Set();
    if (!lastPeriodStart) return set;
    const start = new Date(lastPeriodStart + "T00:00:00");
    for (let cycle = -2; cycle <= 6; cycle++) {
      const cycleStart = addDays(start, cycle * cycleLength);
      for (let d = 0; d < periodLength; d++) {
        set.add(fmtISO(addDays(cycleStart, d)));
      }
    }
    return set;
  }, [lastPeriodStart, periodLength, cycleLength]);

  const daysUntilNextPeriod = useMemo(() => {
    if (!lastPeriodStart) return null;
    let next = new Date(lastPeriodStart + "T00:00:00");
    while (daysBetween(today, next) < 0) {
      next = addDays(next, cycleLength);
    }
    if (fmtISO(next) === fmtISO(today)) return 0;
    if (daysBetween(today, next) === 0) return 0;
    while (next < today || fmtISO(next) < fmtISO(today)) {
      next = addDays(next, cycleLength);
    }
    return daysBetween(today, next);
  }, [lastPeriodStart, cycleLength, today]);

  function handleLogin() {
    if (!emailValid(loginEmail)) {
      setLoginError("Enter a valid email address");
      return;
    }
    if (loginPassword.length < 4) {
      setLoginError("Password must be at least 4 characters");
      return;
    }
    setLoginError("");
    setScreen("home");
  }

  function handleSignupSubmit() {
    if (!signupName.trim()) {
      setSignupError("Enter your name");
      return;
    }
    if (!emailValid(signupEmail)) {
      setSignupError("Enter a valid email address");
      return;
    }
    if (signupPassword.length < 4) {
      setSignupError("Password must be at least 4 characters");
      return;
    }
    setSignupError("");
    setScreen("setup");
  }

  function handleSetupDone() {
    if (!lastPeriodStart) {
      setSetupError("Please select your last period start date");
      return;
    }
    if (!periodLength || !cycleLength) {
      setSetupError("Please fill in both day counts");
      return;
    }
    setSetupError("");
    setScreen("home");
  }

  function handleLogPeriodDone() {
    if (logSelectedDay == null) return;
    setLastPeriodStart(fmtISO(new Date(logYear, logMonth, logSelectedDay)));
    setScreen("home");
  }

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[#f7e8ee] py-8 px-4">
      <div
        className="w-full rounded-3xl shadow-xl overflow-hidden"
        style={{ maxWidth: 380, background: PINK_BG }}
      >
        <div className="min-h-[700px] px-6 py-8 flex flex-col">
          {screen === "login" && (
            <>
              <Header title="Welcome to Flo" />
              <div className="flex-1 flex flex-col justify-center">
                <Field label="Email:">
                  <TextField value={loginEmail} onChange={setLoginEmail} placeholder="you@example.com" />
                </Field>
                <Field label="Password:">
                  <div className="relative">
                    <TextField
                      value={loginPassword}
                      onChange={setLoginPassword}
                      type={showPw ? "text" : "password"}
                      placeholder="••••••"
                    />
                    <button
                      className="absolute right-2 top-2 text-[#6b4a5c]"
                      onClick={() => setShowPw((s) => !s)}
                      aria-label="Toggle password visibility"
                    >
                      {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </Field>
                {loginError && <p className="text-xs text-red-600 mb-3">{loginError}</p>}
                <div className="flex gap-3 mt-1">
                  <PinkButton onClick={handleLogin}>LOG IN</PinkButton>
                  <PinkButton variant="dark" onClick={() => setScreen("signup")}>
                    SIGN UP
                  </PinkButton>
                </div>
              </div>
            </>
          )}

          {screen === "signup" && (
            <>
              <Header title="Welcome to Flo" />
              <p className="text-center text-[#3a2233] font-medium mb-4">LOGIN PAGE</p>
              <div className="flex-1 flex flex-col justify-start">
                <Field label="Name:">
                  <TextField value={signupName} onChange={setSignupName} placeholder="Jane Doe" />
                </Field>
                <Field label="Email:">
                  <TextField value={signupEmail} onChange={setSignupEmail} placeholder="you@example.com" />
                </Field>
                <Field label="Password:">
                  <TextField
                    value={signupPassword}
                    onChange={setSignupPassword}
                    type="password"
                    placeholder="••••••"
                  />
                </Field>
                {signupError && <p className="text-xs text-red-600 mb-3">{signupError}</p>}
                <div className="flex justify-center mt-2">
                  <PinkButton onClick={handleSignupSubmit}>LOG IN</PinkButton>
                </div>
                <button
                  className="text-xs text-[#6b4a5c] mt-4 underline"
                  onClick={() => setScreen("login")}
                >
                  Back to login
                </button>
              </div>
            </>
          )}

          {screen === "setup" && (
            <>
              <Header title="Setup Page" />
              <div className="flex-1">
                <p className="text-sm font-medium text-[#3a2233] mb-2">
                  When did your last period start?
                </p>
                <div className="rounded-xl p-4 mb-4" style={{ background: PINK_HEADER + "22" }}>
                  <p className="text-xs text-[#6b4a5c] mb-1">Select date</p>
                  <div className="flex items-center justify-between">
                    <input
                      type="date"
                      value={lastPeriodStart}
                      max={fmtISO(today)}
                      onChange={(e) => setLastPeriodStart(e.target.value)}
                      className="bg-transparent text-lg font-semibold text-[#3a2233] outline-none w-full"
                    />
                    <CalendarIcon size={18} className="text-[#6b4a5c]" />
                  </div>
                </div>

                <Field label="How long does your period usually last?">
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={1}
                      max={14}
                      value={periodLength}
                      onChange={(e) => setPeriodLength(Number(e.target.value))}
                      className="w-20 rounded-sm px-3 py-2 text-sm outline-none"
                      style={{ background: INPUT_BG }}
                    />
                    <span className="text-sm text-[#3a2233]">DAYS</span>
                  </div>
                </Field>

                <Field label="How long is your average cycle?">
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={15}
                      max={60}
                      value={cycleLength}
                      onChange={(e) => setCycleLength(Number(e.target.value))}
                      className="w-20 rounded-sm px-3 py-2 text-sm outline-none"
                      style={{ background: INPUT_BG }}
                    />
                    <span className="text-sm text-[#3a2233]">DAYS</span>
                  </div>
                </Field>

                {setupError && <p className="text-xs text-red-600 mb-3">{setupError}</p>}
              </div>
              <div className="flex justify-center pb-2">
                <PinkButton onClick={handleSetupDone}>DONE</PinkButton>
              </div>
            </>
          )}

          {screen === "home" && (
            <>
              <Header title="Home" />
              <div className="flex-1 flex flex-col items-center">
                {signupName && (
                  <p className="text-sm text-[#6b4a5c] mb-2">Hi, {signupName.split(" ")[0]}</p>
                )}
                <div
                  className="w-52 h-52 rounded-full flex flex-col items-center justify-center text-center mt-4 mb-8"
                  style={{ background: "#f7dbe7" }}
                >
                  {daysUntilNextPeriod === 0 ? (
                    <>
                      <Droplet size={28} className="text-[#c1477e] mb-1" />
                      <span className="text-lg font-semibold text-[#3a2233]">
                        Period expected today
                      </span>
                    </>
                  ) : (
                    <>
                      <span className="text-sm text-[#3a2233]">Period expected</span>
                      <span className="text-sm text-[#3a2233] mb-1">in</span>
                      <span className="text-5xl font-bold text-[#3a2233]">
                        {daysUntilNextPeriod}
                      </span>
                      <span className="text-sm tracking-wide text-[#3a2233] mt-1">DAYS</span>
                    </>
                  )}
                </div>
                <div className="flex flex-col gap-3 w-full items-center">
                  <PinkButton
                    full
                    style={{ maxWidth: 220 }}
                    onClick={() => {
                      setLogYear(today.getFullYear());
                      setLogMonth(today.getMonth());
                      setLogSelectedDay(today.getDate());
                      setScreen("logPeriod");
                    }}
                  >
                    LOG PERIOD
                  </PinkButton>
                  <PinkButton
                    variant="dark"
                    full
                    style={{ maxWidth: 220 }}
                    onClick={() => {
                      setCalYear(today.getFullYear());
                      setCalMonth(today.getMonth());
                      setCalSelectedDay(today.getDate());
                      setScreen("calendar");
                    }}
                  >
                    View My Calendar
                  </PinkButton>
                </div>
              </div>
            </>
          )}

          {screen === "calendar" && (
            <>
              <Header title="Calendar" />
              <MiniCalendar
                year={calYear}
                month={calMonth}
                setYear={setCalYear}
                setMonth={setCalMonth}
                selectedDay={calSelectedDay}
                onSelectDay={setCalSelectedDay}
                markedDays={markedDays}
                today={today}
              />
              <div className="flex justify-center mt-6">
                <PinkButton onClick={() => setScreen("home")}>
                  <span className="inline-flex items-center gap-1">
                    <ArrowLeft size={14} /> BACK
                  </span>
                </PinkButton>
              </div>
            </>
          )}

          {screen === "logPeriod" && (
            <>
              <Header title="Log Period" />
              <MiniCalendar
                year={logYear}
                month={logMonth}
                setYear={setLogYear}
                setMonth={setLogMonth}
                selectedDay={logSelectedDay}
                onSelectDay={setLogSelectedDay}
                markedDays={markedDays}
                today={today}
              />
              <p className="text-xs text-[#6b4a5c] text-center mt-2">
                Tap a date to mark it as your period start
              </p>
              <div className="flex justify-center mt-4">
                <PinkButton onClick={handleLogPeriodDone}>DONE</PinkButton>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
